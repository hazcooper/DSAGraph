class Graph:

    def __init__(self):

        self.node = 0
        self.list = "something"

    def insert(self):

        pass

    def delete(self):

        pass

    def something(self):

        pass

